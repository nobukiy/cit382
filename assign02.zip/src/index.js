import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";
import DivList from "./DivList.js";

const rootElement = document.getElementById("root");
ReactDOM.render(<DivList />, rootElement);
