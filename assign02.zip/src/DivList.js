import React from "react";
import ReactDOM from "react-dom";

export default class DivList extends React.Component {
  constructor(props) {
    super(props);
    this.handleFilterResult = this.handleFilterResult.bind(this);
    this.state = { text: "", data: [], filter: "" };
  }

  render() {
    let data = this.state.data.slice();
    let list = (
      <div>
        {data
          .filter(this.handleFilterResult)
          .sort()
          .map((elem, index) => (
            <div>
              <span
                className="Clickable"
                key={index}
                onClick={this.handleWordClick.bind(this)}
                id={index}
              >
                {elem}
              </span>
            </div>
          ))}
      </div>
    );

    return (
      <div className="App">
        <h1>Dynamic List</h1>
        <h2>Sort and Filter</h2>
        Enter text:&nbsp;
        <input
          type="text"
          value={this.state.text}
          onChange={e => this.handleInputChange(e)}
        />
        &nbsp;
        <button onClick={this.handleButtonClick.bind(this)}>Add</button>
        &nbsp;
        <button onClick={this.handleClearClick.bind(this)}>Clear</button>
        <br />
        Filter List &nbsp;
        <input
          type="text"
          value={this.state.filter}
          onChange={e => this.handleFilterChange(e)}
        />
        &nbsp;
        <button onClick={this.handleResetClick.bind(this)}>Reset</button>
        <br />
        {list}
      </div>
    );
  }
  handleInputChange(event) {
    let text = event.target.value;
    this.setState({ text });
  }

  handleFilterChange(event) {
    let filter = event.target.value;
    this.setState({ filter });
  }
  handleButtonClick(event) {
    if (this.state.text.length > 0) {
      let data = this.state.data.slice();
      data.push(this.state.text);
      let text = "";
      this.setState({ text });
      this.setState({ data });
      this.setState({ before: data });
      console.log(data);
    }
  }

  handleWordClick(event) {
    var id = parseInt(event.target.id);
    let data = this.state.data.slice();
    data.splice(id, 1);
    this.setState({ data });
  }

  handleClearClick(event) {
    let data = this.state.data.slice();
    data = [];
    this.setState({ data });
  }

  handleFilterResult(value) {
    if (this.state.filter.length > 0) {
      return value == this.state.filter;
    } else {
      return true;
    }
  }

  handleResetClick(event) {
    let filter = "";
    this.setState({ filter });
  }
}
